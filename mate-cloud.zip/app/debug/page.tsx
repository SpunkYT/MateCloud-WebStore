"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function DebugPage() {
  const [envVars, setEnvVars] = useState<Record<string, string | null>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchEnvInfo() {
      try {
        const res = await fetch("/api/debug/env")
        if (!res.ok) {
          throw new Error(`Error ${res.status}: ${await res.text()}`)
        }
        const data = await res.json()
        setEnvVars(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err))
      } finally {
        setLoading(false)
      }
    }

    fetchEnvInfo()
  }, [])

  const handleDiscordAuth = () => {
    window.location.href = "/api/auth/discord"
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Página de Depuración</CardTitle>
          <CardDescription>Información de configuración y variables de entorno</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-mate-600"></div>
            </div>
          ) : error ? (
            <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md">
              <p>Error: {error}</p>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Variables de entorno</h3>
              <div className="bg-gray-50 p-4 rounded-md overflow-auto">
                <pre className="text-sm">
                  {Object.entries(envVars).map(([key, value]) => (
                    <div key={key}>
                      <strong>{key}:</strong> {value ? (key.includes("KEY") ? "***" : value) : "No definido"}
                    </div>
                  ))}
                </pre>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button onClick={() => window.location.reload()}>Actualizar</Button>
          <Button onClick={handleDiscordAuth}>Probar Auth Discord</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
