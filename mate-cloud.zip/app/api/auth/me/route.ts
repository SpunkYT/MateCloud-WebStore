import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { getUserById } from "@/lib/user-service"

export async function GET() {
  try {
    // Obtener sesión de la cookie
    const sessionCookie = cookies().get("session")

    if (!sessionCookie) {
      return NextResponse.json({ message: "Not authenticated" }, { status: 401 })
    }

    let session
    try {
      session = JSON.parse(sessionCookie.value)
    } catch (e) {
      console.error("Error al parsear la cookie de sesión:", e)
      cookies().delete("session")
      return NextResponse.json({ message: "Invalid session" }, { status: 401 })
    }

    // Verificar si la sesión ha expirado
    if (new Date(session.expires) < new Date()) {
      cookies().delete("session")
      return NextResponse.json({ message: "Session expired" }, { status: 401 })
    }

    // Buscar usuario por ID en Supabase
    const user = await getUserById(session.userId)

    if (!user) {
      // Si no se encuentra el usuario en Supabase pero tenemos información en la sesión
      if (session.name) {
        return NextResponse.json({
          id: session.userId,
          name: session.name,
          email: session.email,
          avatar: session.avatar,
        })
      }
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    return NextResponse.json(user)
  } catch (error) {
    console.error("Get user error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
