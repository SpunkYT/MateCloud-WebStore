import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { findOrCreateUserByDiscordId, saveDiscordSession } from "@/lib/user-service"

export async function GET(request: Request) {
  try {
    // Verificar que las variables de entorno necesarias estén definidas
    const clientId = process.env.DISCORD_CLIENT_ID
    const clientSecret = process.env.DISCORD_CLIENT_SECRET
    const appUrl = process.env.NEXT_PUBLIC_APP_URL

    if (!clientId || !clientSecret || !appUrl) {
      console.error("Variables de entorno faltantes:", {
        clientId: !!clientId,
        clientSecret: !!clientSecret,
        appUrl: !!appUrl,
      })
      return NextResponse.redirect(`${appUrl || "/"}/login?error=config_error`)
    }

    const url = new URL(request.url)
    const code = url.searchParams.get("code")
    const state = url.searchParams.get("state")
    const error = url.searchParams.get("error")

    // Si Discord devuelve un error
    if (error) {
      console.error("Error devuelto por Discord:", error)
      return NextResponse.redirect(`${appUrl}/login?error=${error}`)
    }

    // Verificar el estado para prevenir CSRF
    const savedState = cookies().get("discord_oauth_state")?.value
    if (!state || !savedState || state !== savedState) {
      console.error("Error de validación de estado:", { state, savedState })
      return NextResponse.redirect(`${appUrl}/login?error=invalid_state`)
    }

    // Eliminar la cookie de estado
    cookies().delete("discord_oauth_state")

    if (!code) {
      console.error("No se recibió código de autorización")
      return NextResponse.redirect(`${appUrl}/login?error=no_code`)
    }

    // Construir la URL de redirección para el intercambio de tokens
    const redirectUri = `${appUrl}/api/auth/discord/callback`

    // Intercambiar el código por un token de acceso
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    })

    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text()
      console.error("Error en el intercambio de tokens:", errorText)
      return NextResponse.redirect(`${appUrl}/login?error=token_exchange`)
    }

    const tokenData = await tokenResponse.json()

    // Obtener información del usuario con el token
    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
      },
    })

    if (!userResponse.ok) {
      const errorText = await userResponse.text()
      console.error("Error al obtener datos del usuario:", errorText)
      return NextResponse.redirect(`${appUrl}/login?error=user_data`)
    }

    const userData = await userResponse.json()

    // Buscar o crear usuario en Supabase
    const user = await findOrCreateUserByDiscordId({
      id: userData.id,
      username: userData.username,
      email: userData.email,
      avatar: userData.avatar,
    })

    // Guardar la sesión de Discord en Supabase
    await saveDiscordSession(
      user.id,
      userData.id,
      tokenData.access_token,
      tokenData.refresh_token || null,
      tokenData.expires_in,
    )

    // Crear sesión con más información del usuario
    const session = {
      userId: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 días
    }

    // Guardar sesión en cookie
    const response = NextResponse.redirect(`${appUrl}/dashboard`)
    response.cookies.set("session", JSON.stringify(session), {
      httpOnly: true,
      expires: session.expires,
      path: "/",
    })

    return response
  } catch (error) {
    console.error("Error en el callback de Discord:", error)
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || "/"
    return NextResponse.redirect(`${appUrl}/login?error=callback_error`)
  }
}
