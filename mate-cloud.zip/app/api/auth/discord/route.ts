import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    console.log("Iniciando proceso de autenticación con Discord")

    // Verificar variables de entorno
    const clientId = process.env.DISCORD_CLIENT_ID
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || request.headers.get("origin") || "http://localhost:3000"

    console.log("Variables de entorno:", {
      clientIdExists: !!clientId,
      appUrl,
    })

    if (!clientId) {
      console.error("DISCORD_CLIENT_ID no está definido")
      return NextResponse.json(
        { error: "Configuración incompleta: DISCORD_CLIENT_ID no está definido" },
        { status: 500 },
      )
    }

    // Crear un estado único para prevenir CSRF
    const state = Math.random().toString(36).substring(2, 15)
    console.log("Estado generado:", state)

    // Construir URL de redirección
    const redirectUri = `${appUrl}/api/auth/discord/callback`
    console.log("URL de redirección:", redirectUri)

    // Construir URL de autorización de Discord
    const discordAuthUrl = new URL("https://discord.com/api/oauth2/authorize")
    discordAuthUrl.searchParams.append("client_id", clientId)
    discordAuthUrl.searchParams.append("redirect_uri", encodeURIComponent(redirectUri))
    discordAuthUrl.searchParams.append("response_type", "code")
    discordAuthUrl.searchParams.append("scope", "identify email")
    discordAuthUrl.searchParams.append("state", state)

    console.log("URL de autorización de Discord:", discordAuthUrl.toString())

    // Crear respuesta
    const response = NextResponse.redirect(discordAuthUrl.toString())

    // Establecer cookie de estado
    console.log("Estableciendo cookie discord_oauth_state:", state)
    response.cookies.set("discord_oauth_state", state, {
      httpOnly: true,
      maxAge: 60 * 10, // 10 minutos
      path: "/",
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    })

    return response
  } catch (error) {
    console.error("Error en la ruta de autenticación de Discord:", error)
    return NextResponse.json(
      { error: "Error interno del servidor", details: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}
