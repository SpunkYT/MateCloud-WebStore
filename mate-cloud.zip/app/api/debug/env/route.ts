import { NextResponse } from "next/server"

export async function GET() {
  // Solo devolver información no sensible o versiones censuradas
  return NextResponse.json({
    NODE_ENV: process.env.NODE_ENV || "development",
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || null,
    DISCORD_CLIENT_ID_EXISTS: !!process.env.DISCORD_CLIENT_ID,
    DISCORD_CLIENT_SECRET_EXISTS: !!process.env.DISCORD_CLIENT_SECRET,
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL || null,
    NEXT_PUBLIC_SUPABASE_ANON_KEY_EXISTS: !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    SUPABASE_SERVICE_ROLE_KEY_EXISTS: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
  })
}
