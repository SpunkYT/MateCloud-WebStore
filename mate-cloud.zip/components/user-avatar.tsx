"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/auth-context"

interface UserAvatarProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function UserAvatar({ className, size = "md" }: UserAvatarProps) {
  const { user } = useAuth()

  const sizes = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-14 w-14",
  }

  const getFallbackText = () => {
    if (!user?.name) return "U"
    const nameParts = user.name.split(" ")
    if (nameParts.length === 1) return nameParts[0][0].toUpperCase()
    return (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
  }

  return (
    <Avatar className={`${sizes[size]} ${className}`}>
      {user?.avatar ? <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name || "User"} /> : null}
      <AvatarFallback className="bg-mate-100 text-mate-700">{getFallbackText()}</AvatarFallback>
    </Avatar>
  )
}
