"use client"

import Link from "next/link"
import { MateCloudLogo } from "@/components/mate-cloud-logo"
import { useLanguage } from "@/contexts/language-context"

export function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="border-t py-4 px-4 lg:px-6 bg-white">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <MateCloudLogo size="sm" />
          <p className="text-sm text-mate-700">{t("footer.rights")}</p>
        </div>
        <nav className="flex gap-4 sm:gap-6">
          <Link className="text-sm text-mate-700 hover:text-mate-900 transition-colors" href="#">
            {t("footer.terms")}
          </Link>
          <Link className="text-sm text-mate-700 hover:text-mate-900 transition-colors" href="#">
            {t("footer.privacy")}
          </Link>
          <Link className="text-sm text-mate-700 hover:text-mate-900 transition-colors" href="/debug">
            Debug
          </Link>
        </nav>
      </div>
    </footer>
  )
}
