"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

const errorMessages: Record<string, string> = {
  invalid_state: "Error de seguridad: estado inválido. Por favor, intenta nuevamente.",
  no_code: "No se recibió código de autorización de Discord.",
  token_exchange: "Error al intercambiar el código por un token de acceso.",
  user_data: "Error al obtener datos del usuario de Discord.",
  callback_error: "Error durante el proceso de autenticación.",
  config_error: "Error de configuración. Por favor, contacta al administrador.",
  default: "Ocurrió un error durante la autenticación. Por favor, intenta nuevamente.",
}

export function AuthErrorHandler() {
  const searchParams = useSearchParams()
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const errorCode = searchParams.get("error")
    if (errorCode) {
      setError(errorMessages[errorCode] || errorMessages.default)
    }
  }, [searchParams])

  if (!error) return null

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Error de autenticación</AlertTitle>
      <AlertDescription>{error}</AlertDescription>
    </Alert>
  )
}
