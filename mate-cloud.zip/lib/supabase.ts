import { createClient } from "@supabase/supabase-js"

// Singleton pattern para el cliente de Supabase en el lado del cliente
let clientSideInstance: ReturnType<typeof createClient> | null = null

// Cliente para el lado del cliente (con clave anónima)
export const createClientSide = () => {
  if (clientSideInstance) return clientSideInstance

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

  if (!supabaseUrl || !supabaseAnonKey) {
    console.error("Supabase URL or Anon Key is missing")
    throw new Error("Supabase configuration is incomplete")
  }

  clientSideInstance = createClient(supabaseUrl, supabaseAnonKey)
  return clientSideInstance
}

// Cliente para el lado del servidor (con clave de servicio)
export const createServerSide = () => {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ""

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Supabase URL or Service Key is missing")
    throw new Error("Supabase configuration is incomplete")
  }

  return createClient(supabaseUrl, supabaseServiceKey)
}
