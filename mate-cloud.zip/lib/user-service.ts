import { createServerSide } from "./supabase"
import { v4 as uuidv4 } from "uuid"

interface DiscordUser {
  id: string
  username: string
  email?: string
  avatar?: string
}

export async function findOrCreateUserByDiscordId(discordUser: DiscordUser) {
  const supabase = createServerSide()

  // Buscar si ya existe un perfil con este discord_id
  const { data: existingProfile } = await supabase
    .from("profiles")
    .select("id, username, full_name, avatar_url")
    .eq("discord_id", discordUser.id)
    .single()

  if (existingProfile) {
    // Si el perfil existe, devolver el usuario existente
    return {
      id: existingProfile.id,
      name: existingProfile.full_name || existingProfile.username,
      username: existingProfile.username,
      email: discordUser.email,
      avatar: existingProfile.avatar_url,
      discordId: discordUser.id,
    }
  }

  // Si no existe, crear un nuevo usuario en auth.users
  // En una implementación real, usarías la API de Supabase Auth
  // Para esta demo, generamos un UUID
  const userId = uuidv4()

  // Crear un nuevo perfil
  const { error } = await supabase.from("profiles").insert({
    id: userId,
    username: discordUser.username,
    full_name: discordUser.username,
    avatar_url: discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
      : null,
    discord_id: discordUser.id,
  })

  if (error) {
    console.error("Error creating profile:", error)
    throw new Error("Failed to create user profile")
  }

  return {
    id: userId,
    name: discordUser.username,
    username: discordUser.username,
    email: discordUser.email,
    avatar: discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
      : null,
    discordId: discordUser.id,
  }
}

export async function saveDiscordSession(
  userId: string,
  discordId: string,
  accessToken: string,
  refreshToken: string | null,
  expiresIn: number,
) {
  const supabase = createServerSide()

  // Calcular la fecha de expiración
  const expiresAt = new Date()
  expiresAt.setSeconds(expiresAt.getSeconds() + expiresIn)

  // Guardar la sesión de Discord
  const { error } = await supabase.from("discord_sessions").insert({
    user_id: userId,
    discord_id: discordId,
    access_token: accessToken,
    refresh_token: refreshToken,
    expires_at: expiresAt.toISOString(),
  })

  if (error) {
    console.error("Error saving Discord session:", error)
    throw new Error("Failed to save Discord session")
  }
}

export async function getUserById(userId: string) {
  const supabase = createServerSide()

  const { data, error } = await supabase
    .from("profiles")
    .select("id, username, full_name, avatar_url, discord_id")
    .eq("id", userId)
    .single()

  if (error || !data) {
    return null
  }

  return {
    id: data.id,
    name: data.full_name || data.username,
    username: data.username,
    avatar: data.avatar_url,
    discordId: data.discord_id,
  }
}
